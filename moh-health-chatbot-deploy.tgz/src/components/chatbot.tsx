"use client";

import { FormEvent, useMemo, useRef, useState } from "react";
import type { ChatResponse, Citation, SafetyLevel } from "@/lib/types";

type Message = {
  id: string;
  role: "assistant" | "user";
  text: string;
  citations?: Citation[];
  safetyLevel?: SafetyLevel;
};

const starterMessages: Message[] = [
  {
    id: "welcome",
    role: "assistant",
    text: "أهلًا بك. اسأل عن المعلومات الصحية الموثقة حول نظام الطيبات، الغذاء، أو التحذيرات الطبية المرتبطة بإيقاف العلاج.",
  },
];

const quickPrompts = [
  "هل الدجاج مضر ويسبب الالتهاب؟",
  "هل يمكن إيقاف الإنسولين والاعتماد على الأكل؟",
  "ما حقيقة تقسيم الأطعمة إلى طيبات وخبائث؟",
];

function makeMessageId() {
  if (
    typeof globalThis.crypto !== "undefined" &&
    typeof globalThis.crypto.randomUUID === "function"
  ) {
    return globalThis.crypto.randomUUID();
  }

  return `message-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

export function Chatbot() {
  const [messages, setMessages] = useState<Message[]>(starterMessages);
  const [input, setInput] = useState("");
  const [sessionId, setSessionId] = useState<string>();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const latestSafety = useMemo(
    () => messages.findLast((message) => message.safetyLevel)?.safetyLevel || "normal",
    [messages],
  );

  async function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!trimmed || isLoading) {
      return;
    }

    setInput("");
    setError("");
    setIsLoading(true);
    const userMessage: Message = {
      id: makeMessageId(),
      role: "user",
      text: trimmed,
    };
    setMessages((current) => [...current, userMessage]);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ message: trimmed, sessionId }),
      });

      if (!response.ok) {
        const message =
          response.status === 429
            ? "تم إرسال أسئلة كثيرة بسرعة. يرجى الانتظار قليلًا ثم المحاولة مرة أخرى."
            : response.status === 413
              ? "الرسالة طويلة جدًا. يرجى اختصار السؤال وإرساله مرة أخرى."
              : "تعذر إرسال الرسالة الآن. يرجى المحاولة مرة أخرى.";
        throw new Error(message);
      }

      const data = (await response.json()) as ChatResponse;
      setSessionId(data.sessionId);
      setMessages((current) => [
        ...current,
        {
          id: makeMessageId(),
          role: "assistant",
          text: data.answer,
          citations: data.citations,
          safetyLevel: data.safetyLevel,
        },
      ]);
    } catch {
      setError("تعذر إرسال الرسالة الآن. يرجى المحاولة مرة أخرى.");
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  }

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void sendMessage(input);
  }

  return (
    <section className="flex min-h-[640px] w-full flex-col overflow-hidden rounded-[8px] border border-slate-200 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-4 py-3 sm:px-5">
        <div>
          <p className="text-sm font-semibold text-slate-950">مساعد وزارة الصحة</p>
          <p className="text-xs text-slate-500">معلومات موثقة للزوار والدعم العام</p>
        </div>
        <StatusPill safetyLevel={latestSafety} />
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto bg-[#f8fafc] px-4 py-5 sm:px-5">
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
        {isLoading ? (
          <div className="w-fit rounded-[8px] bg-white px-4 py-3 text-sm text-slate-500 shadow-sm">
            جاري مراجعة المصادر...
          </div>
        ) : null}
      </div>

      <div className="border-t border-slate-200 bg-white p-4 sm:p-5">
        <div className="mb-3 flex flex-wrap gap-2">
          {quickPrompts.map((prompt) => (
            <button
              key={prompt}
              type="button"
              onClick={() => void sendMessage(prompt)}
              className="rounded-[8px] border border-teal-100 bg-teal-50 px-3 py-2 text-xs font-medium text-teal-800 transition hover:bg-teal-100"
            >
              {prompt}
            </button>
          ))}
        </div>

        {error ? <p className="mb-2 text-sm text-red-700">{error}</p> : null}

        <form onSubmit={onSubmit} className="flex gap-2">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(event) => setInput(event.target.value)}
            rows={2}
            maxLength={2000}
            aria-label="اكتب سؤالك"
            placeholder="اكتب سؤالك هنا..."
            className="min-h-14 flex-1 resize-none rounded-[8px] border border-slate-300 bg-white px-3 py-3 text-sm text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-teal-600 focus:ring-2 focus:ring-teal-100"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            aria-label="إرسال"
            title="إرسال"
            className="grid h-14 w-14 shrink-0 place-items-center rounded-[8px] bg-teal-700 text-xl font-semibold text-white transition hover:bg-teal-800 disabled:cursor-not-allowed disabled:bg-slate-300"
          >
            ←
          </button>
        </form>
      </div>
    </section>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";

  return (
    <article
      className={[
        "max-w-[92%] overflow-hidden rounded-[8px] px-4 py-3 text-sm leading-7 shadow-sm sm:max-w-[82%]",
        isUser
          ? "mr-auto bg-teal-700 text-white"
          : "ml-auto border border-slate-200 bg-white text-slate-900",
      ].join(" ")}
    >
      <p className="whitespace-pre-wrap break-words">{message.text}</p>
      {!isUser && message.citations && message.citations.length > 0 ? (
        <div className="mt-3 border-t border-slate-100 pt-3">
          <p className="mb-2 text-xs font-semibold text-slate-500">المصادر</p>
          <div className="space-y-1">
            {message.citations.map((citation) => (
              <a
                key={citation.id}
                href={citation.url || "#"}
                target={citation.url ? "_blank" : undefined}
                rel={citation.url ? "noopener noreferrer" : undefined}
                className="block break-words text-xs text-teal-700 hover:text-teal-900"
              >
                {citation.authority}
                {citation.date ? ` - ${citation.date}` : ""}
              </a>
            ))}
          </div>
        </div>
      ) : null}
    </article>
  );
}

function StatusPill({ safetyLevel }: { safetyLevel: SafetyLevel }) {
  const label =
    safetyLevel === "urgent"
      ? "تنبيه طبي"
      : safetyLevel === "medical_caution"
        ? "إرشاد صحي"
        : "جاهز";
  const className =
    safetyLevel === "urgent"
      ? "bg-red-50 text-red-700 ring-red-100"
      : safetyLevel === "medical_caution"
        ? "bg-amber-50 text-amber-700 ring-amber-100"
        : "bg-emerald-50 text-emerald-700 ring-emerald-100";

  return (
    <span className={`rounded-full px-3 py-1 text-xs font-semibold ring-1 ${className}`}>
      {label}
    </span>
  );
}
