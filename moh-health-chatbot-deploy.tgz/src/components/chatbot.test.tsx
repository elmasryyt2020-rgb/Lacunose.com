import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { Chatbot } from "./chatbot";

describe("Chatbot", () => {
  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
  });

  it("renders Arabic-first public chat controls", () => {
    render(<Chatbot />);

    expect(screen.getByText("مساعد وزارة الصحة")).toBeInTheDocument();
    expect(screen.getByPlaceholderText("اكتب سؤالك هنا...")).toBeInTheDocument();
  });

  it("sends messages and renders answers", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        Response.json({
          answer: "إجابة موثقة",
          citations: [],
          safetyLevel: "normal",
          sessionId: "test-session",
        }),
      ),
    );

    render(<Chatbot />);
    await userEvent.type(screen.getByPlaceholderText("اكتب سؤالك هنا..."), "هل الخبز سام؟");
    await userEvent.click(screen.getByLabelText("إرسال"));

    await waitFor(() => expect(screen.getByText("إجابة موثقة")).toBeInTheDocument());
  });

  it("can send when crypto.randomUUID is unavailable", async () => {
    vi.stubGlobal("crypto", {});
    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        Response.json({
          answer: "إجابة بدون randomUUID",
          citations: [],
          safetyLevel: "normal",
          sessionId: "fallback-session",
        }),
      ),
    );

    render(<Chatbot />);
    await userEvent.type(screen.getByPlaceholderText("اكتب سؤالك هنا..."), "هل الخبز سام؟");
    await userEvent.click(screen.getByLabelText("إرسال"));

    await waitFor(() =>
      expect(screen.getByText("إجابة بدون randomUUID")).toBeInTheDocument(),
    );
  });
});
