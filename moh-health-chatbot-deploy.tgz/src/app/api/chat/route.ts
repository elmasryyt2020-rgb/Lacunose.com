import { handleChat } from "@/lib/chat";
import { checkRateLimit } from "@/lib/rate-limit";
import type { ChatRequest } from "@/lib/types";

export const runtime = "nodejs";

const MAX_MESSAGE_LENGTH = 2000;

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Partial<ChatRequest>;
    const message = typeof body.message === "string" ? body.message : "";

    if (!message.trim()) {
      return Response.json(
        { error: "message is required" },
        { status: 400 },
      );
    }

    if (message.length > MAX_MESSAGE_LENGTH) {
      return Response.json(
        { error: "message is too long" },
        { status: 413 },
      );
    }

    const rateLimit = checkRateLimit(clientKey(request));
    if (!rateLimit.allowed) {
      return Response.json(
        { error: "too many requests" },
        {
          status: 429,
          headers: {
            "retry-after": String(
              Math.max(1, Math.ceil((rateLimit.resetAt - Date.now()) / 1000)),
            ),
          },
        },
      );
    }

    const result = await handleChat({
      message,
      sessionId: body.sessionId,
      locale: body.locale,
    });

    return Response.json(result);
  } catch {
    return Response.json(
      { error: "Unable to process the chat request" },
      { status: 500 },
    );
  }
}

function clientKey(request: Request) {
  const forwardedFor = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const realIp = request.headers.get("x-real-ip")?.trim();
  return forwardedFor || realIp || "local-preview";
}
