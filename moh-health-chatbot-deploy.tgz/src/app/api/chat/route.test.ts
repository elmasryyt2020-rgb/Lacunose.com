import { describe, expect, it } from "vitest";
import { resetRateLimitForTests } from "@/lib/rate-limit";
import { POST } from "./route";

describe("POST /api/chat", () => {
  it("rejects empty messages", async () => {
    resetRateLimitForTests();
    const response = await POST(
      new Request("http://localhost/api/chat", {
        method: "POST",
        body: JSON.stringify({ message: "" }),
      }),
    );

    expect(response.status).toBe(400);
  });

  it("rejects messages that are too long", async () => {
    resetRateLimitForTests();
    const response = await POST(
      new Request("http://localhost/api/chat", {
        method: "POST",
        body: JSON.stringify({ message: "a".repeat(2001) }),
      }),
    );

    expect(response.status).toBe(413);
  });

  it("returns a stable chat response shape for unsafe questions", async () => {
    resetRateLimitForTests();
    const response = await POST(
      new Request("http://localhost/api/chat", {
        method: "POST",
        body: JSON.stringify({ message: "هل يمكنني إيقاف الإنسولين؟" }),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.safetyLevel).toBe("urgent");
    expect(body.answer).toContain("لا توقف");
    expect(body.sessionId).toBeTruthy();
  });
});
