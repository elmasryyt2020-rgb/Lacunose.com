export async function GET(request: Request) {
  const origin = new URL(request.url).origin;
  const script = `
(function () {
  if (document.getElementById("moh-health-chatbot-frame")) return;
  var frame = document.createElement("iframe");
  frame.id = "moh-health-chatbot-frame";
  frame.title = "MOH Egypt health chatbot";
  frame.src = "${origin}/?embed=1";
  frame.style.position = "fixed";
  frame.style.insetInlineEnd = "20px";
  frame.style.bottom = "20px";
  frame.style.width = "min(420px, calc(100vw - 32px))";
  frame.style.height = "min(680px, calc(100vh - 32px))";
  frame.style.border = "0";
  frame.style.borderRadius = "18px";
  frame.style.boxShadow = "0 24px 80px rgba(15, 23, 42, 0.24)";
  frame.style.zIndex = "2147483647";
  document.body.appendChild(frame);
})();`;

  return new Response(script.trim(), {
    headers: {
      "content-type": "application/javascript; charset=utf-8",
      "cache-control": "public, max-age=300",
    },
  });
}
