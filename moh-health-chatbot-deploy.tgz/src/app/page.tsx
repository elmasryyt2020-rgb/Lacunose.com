import { Chatbot } from "@/components/chatbot";

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-100">
      <div className="mx-auto grid min-h-screen w-full max-w-6xl gap-6 px-4 py-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
        <section className="flex flex-col justify-between rounded-[8px] bg-teal-900 p-6 text-white lg:p-8">
          <div>
            <p className="mb-4 text-sm font-semibold text-teal-100">
              جمهورية مصر العربية - وزارة الصحة والسكان
            </p>
            <h1 className="max-w-xl text-3xl font-bold leading-tight sm:text-4xl">
              مساعد صحي موثق للرد على أسئلة الزوار حول نظام الطيبات والمعلومات الغذائية.
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-8 text-teal-50">
              نسخة عرض أولية لواجهة دردشة يمكن تضمينها لاحقًا داخل موقع الوزارة، مع
              اعتماد الإجابات على قاعدة معرفة موثقة وتنبيهات واضحة عند الأسئلة الطبية
              عالية الخطورة.
            </p>
          </div>

          <div className="mt-8 grid gap-3 text-sm text-teal-50 sm:grid-cols-3 lg:grid-cols-1">
            <div className="rounded-[8px] border border-white/15 p-4">
              مصادر موثقة من NNI وFAO وWHO وبيانات الجهات الصحية المصرية.
            </div>
            <div className="rounded-[8px] border border-white/15 p-4">
              تنبيه فوري عند طلب إيقاف الإنسولين أو العلاج الكيماوي أو الأدوية.
            </div>
            <div className="rounded-[8px] border border-white/15 p-4">
              Endpoint جاهز للتجربة: <span dir="ltr">POST /api/chat</span>
            </div>
          </div>
        </section>

        <Chatbot />
      </div>
    </main>
  );
}
