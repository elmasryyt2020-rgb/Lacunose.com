import { describe, expect, it } from "vitest";
import { handleChat } from "./chat";
import type { KnowledgeRow } from "./types";

const chickenRow: KnowledgeRow = {
  id: "row-1",
  content: "Chicken is a complete protein source.",
  claim: "Poultry is a factory of disease.",
  fact_data: "NNI/FAO tables classify poultry as a complete protein source.",
  document_type: "nutritional_data",
  source_authority: "NNI / FAO / WHO",
  source_url: "https://www.fao.org/4/aq037e/aq037e.pdf",
  source_date: "2003-08-01",
  category: "nutrition",
  food_tags: ["poultry"],
};

describe("handleChat", () => {
  it("returns Gemini-backed answers with citations", async () => {
    const response = await handleChat(
      { message: "هل الدجاج مضر؟" },
      {
        retrieve: async () => [chickenRow],
        generate: async () => "الدجاج ليس محظورًا وفق المصادر المتاحة.",
      },
    );

    expect(response.answer).toContain("الدجاج");
    expect(response.answer).toContain("معلومات صحية عامة");
    expect(response.citations).toHaveLength(1);
    expect(response.citations[0].authority).toBe("NNI / FAO / WHO");
  });

  it("refuses medication-stop requests before generation", async () => {
    const response = await handleChat(
      { message: "هل أوقف الإنسولين؟" },
      {
        retrieve: async () => [],
        generate: async () => "bad answer",
      },
    );

    expect(response.safetyLevel).toBe("urgent");
    expect(response.answer).toContain("لا توقف");
    expect(response.answer).not.toContain("bad answer");
  });

  it("includes recent conversation history in follow-up prompts", async () => {
    let prompt = "";

    await handleChat(
      { message: "But that doctor on YouTube said it was fine.", sessionId: "session-1" },
      {
        retrieve: async () => [chickenRow],
        loadHistory: async () => [
          {
            role: "user",
            content: "What happened with the Tayebat incident?",
          },
          {
            role: "assistant",
            content: "It involved unsafe claims about stopping medicine and classifying foods.",
          },
        ],
        generate: async (receivedPrompt) => {
          prompt = receivedPrompt;
          return "Use verified sources rather than social media medical claims.";
        },
      },
    );

    expect(prompt).toContain("Recent conversation context");
    expect(prompt).toContain("What happened with the Tayebat incident?");
    expect(prompt).toContain("But that doctor on YouTube said it was fine.");
  });

  it("creates a new session when the request has no session id", async () => {
    const response = await handleChat(
      { message: "Is bread toxic?" },
      {
        retrieve: async () => [chickenRow],
        createSession: async () => "new-session-id",
        generate: async () => "No.",
      },
    );

    expect(response.sessionId).toBe("new-session-id");
  });
});
