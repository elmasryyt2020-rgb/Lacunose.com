import "server-only";

import { GoogleGenAI } from "@google/genai";

export async function generateWithGemini(prompt: string, systemInstruction: string) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return "";
  }

  const ai = new GoogleGenAI({ apiKey });
  const response = await ai.models.generateContent({
    model: process.env.GEMINI_MODEL || "gemini-3.1-flash-lite",
    contents: prompt,
    config: {
      systemInstruction,
      temperature: 0.2,
      topP: 0.85,
      maxOutputTokens: 380,
    },
  });

  return response.text?.trim() || "";
}
