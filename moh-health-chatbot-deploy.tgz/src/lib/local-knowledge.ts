import type { KnowledgeRow } from "./types";

export const localKnowledgeRows: KnowledgeRow[] = [
  {
    id: "local-healthy-diet-who-2026",
    content:
      "WHO describes a healthy diet as one high in whole grains, vegetables, fruits, legumes and nuts, and low in salt, free sugars, saturated fats and trans fats. Adults should eat at least 400g of fruit and vegetables daily, limit free sugars to less than 10% of energy intake, keep salt below 5g per day, and prefer unsaturated fats over saturated and trans fats.",
    claim: "A healthy diet means eliminating most staple foods.",
    fact_data:
      "WHO recommends a balanced pattern: whole grains, vegetables, fruits, legumes, nuts, moderate fat quality, limited free sugars and salt. It does not classify ordinary foods as toxic or require eliminating entire food groups.",
    document_type: "who_guideline",
    source_authority: "WHO",
    source_url: "https://www.who.int/news-room/fact-sheets/detail/healthy-diet",
    source_date: "2026-01-26",
    category: "nutrition",
    food_tags: ["healthy_diet", "vegetables", "fruits", "whole_grains", "legumes"],
  },
  {
    id: "local-fats-who-2023",
    content:
      "WHO 2023 guidance on saturated and trans-fatty acids recommends reducing saturated fats and replacing them with unsaturated fats. Butter, ghee, lard, palm oil and coconut oil are listed among sources of saturated fat; industrial trans fats should be avoided.",
    claim: "Ghee and butter clean arteries and should be used freely.",
    fact_data:
      "WHO recommends limiting saturated fat to reduce diet-related noncommunicable disease risk and replacing saturated fats with unsaturated oils rather than treating ghee or butter as disease-preventing foods.",
    document_type: "who_guideline",
    source_authority: "WHO",
    source_url: "https://www.who.int/publications/i/item/9789240073630",
    source_date: "2023-07-17",
    category: "cardiology",
    food_tags: ["ghee", "butter", "saturated_fat", "vegetable_oil"],
  },
  {
    id: "local-carbohydrates-who-2023",
    content:
      "WHO carbohydrate guidance emphasizes carbohydrate quality. Intake should come primarily from whole grains, vegetables, fruits and pulses. WHO recommends adults consume at least 400g of fruit and vegetables and 25g of naturally occurring dietary fibre daily.",
    claim: "All carbohydrates are poison.",
    fact_data:
      "WHO recommends high-quality carbohydrate sources such as whole grains, pulses, vegetables and fruits. The guidance is about quality and excess free sugars, not banning all carbohydrates.",
    document_type: "who_guideline",
    source_authority: "WHO",
    source_url: "https://www.who.int/news/item/17-07-2023-who-updates-guidelines-on-fats-and-carbohydrates",
    source_date: "2023-07-17",
    category: "nutrition",
    food_tags: ["carbohydrates", "whole_grains", "pulses", "fruits", "vegetables"],
  },
  {
    id: "local-salt-who-2025",
    content:
      "WHO recommends adults consume less than 2000mg sodium per day, equivalent to less than 5g salt per day. High sodium intake is associated with raised blood pressure and increased cardiovascular risk.",
    claim: "Salt intake does not matter for public health.",
    fact_data:
      "WHO sodium reduction guidance links excess sodium to raised blood pressure and cardiovascular disease risk and recommends less than 5g salt per day for adults.",
    document_type: "who_fact_sheet",
    source_authority: "WHO",
    source_url: "https://www.who.int/news-room/fact-sheets/detail/salt-reduction",
    source_date: "2025-02-07",
    category: "cardiology",
    food_tags: ["salt", "sodium", "blood_pressure"],
  },
  {
    id: "local-diabetes-who-2024",
    content:
      "WHO defines diabetes as a chronic disease that occurs when the pancreas does not produce enough insulin or the body cannot effectively use insulin. Insulin regulates blood glucose. Diabetes care includes diagnosis, medicines when indicated, nutrition, physical activity and monitoring for complications.",
    claim: "Diabetes can always be managed by diet alone.",
    fact_data:
      "WHO recognizes insulin and other medical care as part of diabetes management. Diet can support care, but it is not a universal replacement for prescribed insulin or medicines.",
    document_type: "who_fact_sheet",
    source_authority: "WHO",
    source_url: "https://www.who.int/news-room/fact-sheets/detail/diabetes",
    source_date: "2024-11-14",
    category: "endocrinology",
    food_tags: ["diabetes", "insulin"],
  },
  {
    id: "local-hypertension-who-2023",
    content:
      "WHO hypertension guidance lists modifiable risk factors including excess salt, diets high in saturated and trans fats, low fruit and vegetable intake, physical inactivity, tobacco and alcohol. Many people who improve lifestyle still need medicine.",
    claim: "Blood pressure medicine can be stopped once diet improves.",
    fact_data:
      "WHO states that lifestyle changes help reduce risk, but many people with hypertension still need medicines. Patients should not stop blood pressure medicine without clinician guidance.",
    document_type: "who_fact_sheet",
    source_authority: "WHO",
    source_url: "https://www.who.int/news-room/fact-sheets/detail/hypertension",
    source_date: "2023-03-16",
    category: "cardiology",
    food_tags: ["hypertension", "blood_pressure", "salt"],
  },
  {
    id: "local-cvd-who-2025",
    content:
      "WHO cardiovascular disease guidance says most CVDs can be prevented by addressing risks such as tobacco use, unhealthy diet including excess salt, sugar and fats, obesity, physical inactivity, alcohol and air pollution. Drug treatment of hypertension, diabetes and high blood lipids is necessary for some people to reduce heart attack and stroke risk.",
    claim: "Food rules alone can prevent or treat heart attacks and strokes.",
    fact_data:
      "WHO supports healthy diet and physical activity for prevention, while recognizing that medicines for hypertension, diabetes and lipids are necessary for many patients.",
    document_type: "who_fact_sheet",
    source_authority: "WHO",
    source_url: "https://www.who.int/news-room/fact-sheets/detail/cardiovascular-diseases-(cvds)",
    source_date: "2025-07-31",
    category: "cardiology",
    food_tags: ["cardiovascular", "stroke", "heart_attack"],
  },
  {
    id: "local-physical-activity-who-2024",
    content:
      "WHO physical activity guidance says regular physical activity helps prevent and manage cardiovascular disease, cancer and diabetes and supports mental health. Adults should do at least 150 minutes of moderate-intensity physical activity per week, or 75 minutes vigorous activity, as able.",
    claim: "Diet alone is enough for chronic disease prevention.",
    fact_data:
      "WHO identifies physical activity as a core public health behavior alongside healthy diet. It supports prevention and management of NCDs, but does not replace clinical care.",
    document_type: "who_fact_sheet",
    source_authority: "WHO",
    source_url: "https://www.who.int/news-room/fact-sheets/detail/physical-activity",
    source_date: "2024-06-26",
    category: "general_practice",
    food_tags: ["physical_activity", "ncd"],
  },
  {
    id: "local-food-safety-who-2024",
    content:
      "WHO food safety guidance notes that unsafe food can cause many diseases. Poultry, eggs and animal products can be involved in foodborne outbreaks if unsafe or undercooked, but this is a food safety issue, not evidence that poultry or eggs are inherently toxic foods.",
    claim: "Chicken and eggs are factories of disease and must be avoided.",
    fact_data:
      "WHO links foodborne illness risk to contamination and unsafe handling. The practical guidance is safe handling and thorough cooking, not declaring poultry or eggs inherently toxic.",
    document_type: "who_fact_sheet",
    source_authority: "WHO",
    source_url: "https://www.who.int/news-room/fact-sheets/detail/food-safety",
    source_date: "2024-10-04",
    category: "food_safety",
    food_tags: ["poultry", "eggs", "food_safety"],
  },
  {
    id: "local-food-safety-who-euro-2023",
    content:
      "WHO food safety advice says to keep clean, separate raw and cooked foods, cook thoroughly, keep food at safe temperatures, and use safe water and raw materials. Proper cooking kills almost all dangerous microorganisms; food should reach at least 70C.",
    claim: "Food safety means avoiding all animal foods.",
    fact_data:
      "WHO's practical food-safety approach is cleaning, separation, thorough cooking and safe storage, especially for meat, poultry, eggs and seafood.",
    document_type: "who_fact_sheet",
    source_authority: "WHO",
    source_url: "https://www.who.int/europe/news-room/fact-sheets/item/public-health-advice-on-food-safety-during-summer",
    source_date: "2023-08-18",
    category: "food_safety",
    food_tags: ["poultry", "eggs", "meat", "seafood"],
  },
  {
    id: "local-obesity-who-2025",
    content:
      "WHO obesity guidance describes obesity as a chronic, relapsing disease influenced by diet, physical activity, biology and environment. Prevention and management include healthy diet, physical activity, sleep, avoiding tobacco and alcohol, and clinical management when needed.",
    claim: "People should eat only when hungry and ignore calories or portions.",
    fact_data:
      "WHO obesity guidance supports healthy eating patterns, limiting sugar-sweetened beverages and energy-dense foods, regular physical activity and clinical care when needed; it does not endorse unlimited eating to fullness.",
    document_type: "who_fact_sheet",
    source_authority: "WHO",
    source_url: "https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight",
    source_date: "2025-12-08",
    category: "endocrinology",
    food_tags: ["obesity", "calories", "portion_control"],
  },
  {
    id: "local-cancer-treatment-who",
    content:
      "WHO cancer treatment materials describe cancer treatment as potentially involving surgery, radiation therapy, chemotherapy, hormonal therapy or combinations. National cancer control should integrate treatment with screening, diagnosis and palliative care.",
    claim: "Cancer patients can abandon chemotherapy and use diet instead.",
    fact_data:
      "WHO recognizes chemotherapy and other cancer treatments as part of cancer care. Diet information must not be used to replace oncology treatment or delay urgent medical care.",
    document_type: "who_fact_sheet",
    source_authority: "WHO",
    source_url: "https://www.who.int/europe/news-room/fact-sheets/item/cancer-treatment",
    source_date: "2010-02-01",
    category: "oncology",
    food_tags: ["cancer", "chemotherapy"],
  },
  {
    id: "local-fao-egypt-profile-2003",
    content:
      "The FAO Nutrition Country Profile for Egypt describes cereals, particularly baladi bread, as the dominant source of dietary energy; pulses such as fava beans and lentils as important affordable protein sources; fruits and vegetables as micronutrient sources; and dairy as a calcium and protein source.",
    claim: "Egyptian staples such as bread, grains, legumes and dairy should be eliminated.",
    fact_data:
      "The FAO Egypt nutrition profile supports diversified diets across cereals, pulses, vegetables, fruits and dairy. It does not classify staple foods as toxic.",
    document_type: "nutrition_country_profile",
    source_authority: "FAO / Egypt NNI",
    source_url: "https://www.fao.org/4/aq037e/aq037e.pdf",
    source_date: "2003-08-01",
    category: "nutrition",
    food_tags: ["bread", "wheat", "lentils", "fava_beans", "dairy"],
  },
  {
    id: "local-fao-infoods-egypt",
    content:
      "FAO/INFOODS lists Egypt's food composition tables from the National Nutrition Institute. Food composition tables classify foods by nutrients such as energy, protein, fat, carbohydrates, vitamins and minerals, not by moral labels such as Tayebat and Khabaith.",
    claim: "Foods are scientifically divided into Tayebat and Khabaith.",
    fact_data:
      "Food composition tables are nutrient databases. They do not support a formal medical classification of ordinary foods into pure foods and toxic foods.",
    document_type: "nutritional_data",
    source_authority: "FAO / INFOODS / Egypt NNI",
    source_url: "https://www.fao.org/infoods/infoods/tables-and-databases/egypt/en/",
    source_date: "1996-01-01",
    category: "nutrition",
    food_tags: ["khabaith", "tayebat", "food_composition"],
  },
  {
    id: "local-egypt-moh-campaign-2026",
    content:
      "Egypt's Ministry of Health public campaign 'Inta El Hal' warned about overeating, excessive sugar and unhealthy foods as causes of diabetes, heart attacks and digestive disorders. The campaign encouraged buying only what is needed and reducing sugar.",
    claim: "The Egyptian government has no official healthy eating message.",
    fact_data:
      "Egypt's Ministry of Health has publicly warned against overeating and excess sugar. This supports moderation and healthy eating, not extreme food bans.",
    document_type: "mohp_statement",
    source_authority: "Egyptian Ministry of Health and Population",
    source_url: "https://www.egypttoday.com/Article/1/145203/Egypt-launches-%E2%80%98Inta-El-Hal%E2%80%99-campaign-warning-of-health-risks",
    source_date: "2026-02-23",
    category: "nutrition",
    food_tags: ["sugar", "overeating", "egypt_moh"],
  },
  {
    id: "local-elawady-media-ban-2026",
    content:
      "Egypt's Supreme Council for Media Regulation ordered media outlets and digital platforms to stop circulating content attributed to Diaa Elawady after requests from the Ministry of Health and the Egyptian Medical Syndicate, warning that unverified medical advice could harm public health.",
    claim: "Al-Tayyibat content is legally endorsed in Egypt.",
    fact_data:
      "Egyptian authorities acted against circulation of Diaa Elawady content because of public health concerns. The chatbot should redirect users to verified medical sources.",
    document_type: "regulatory_statement",
    source_authority: "SCMR / Egyptian MoHP / Egyptian Medical Syndicate",
    source_url: "https://www.egypttoday.com/Article/1/146877/Egypt%E2%80%99s-media-regulator-bans-circulation-of-content-by-late-doctor",
    source_date: "2026-05-03",
    category: "general_practice",
    food_tags: ["tayebat", "diaa_elawady"],
  },
  {
    id: "local-medication-safety-core",
    content:
      "Stopping prescribed insulin, chemotherapy, antihypertensives, anticoagulants or other essential medicines without the treating clinician can cause severe harm. Public health guidance can explain risks, but medication decisions must be handled by the treating medical team.",
    claim: "A chatbot or diet plan can tell patients to stop prescribed medicines.",
    fact_data:
      "The chatbot must never advise stopping prescribed medicine. It should tell users to contact their treating clinician and seek emergency care for urgent symptoms.",
    document_type: "safety_guardrail",
    source_authority: "WHO / Egyptian Medical Syndicate / Egyptian MoHP",
    source_url: "https://www.who.int/news-room/fact-sheets/detail/diabetes",
    source_date: "2024-11-14",
    category: "general_practice",
    food_tags: ["medication", "insulin", "chemotherapy", "hypertension"],
  },
];

const defaultRowIds = new Set([
  "local-healthy-diet-who-2026",
  "local-medication-safety-core",
  "local-fao-infoods-egypt",
]);

export function retrieveLocalKnowledge(message: string, limit = 6): KnowledgeRow[] {
  const terms = localTerms(message);

  if (terms.length === 0) {
    return defaultRows(limit);
  }

  const ranked = localKnowledgeRows
    .map((row) => ({ row, score: scoreRow(row, terms) }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((item) => item.row);

  if (ranked.length === 0) {
    return defaultRows(limit);
  }

  return ranked.slice(0, limit);
}

function defaultRows(limit: number) {
  return localKnowledgeRows.filter((row) => defaultRowIds.has(row.id)).slice(0, limit);
}

function scoreRow(row: KnowledgeRow, terms: string[]) {
  const haystack = [
    row.content,
    row.claim,
    row.fact_data,
    row.category,
    row.source_authority,
    ...(row.food_tags || []),
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();

  return terms.reduce((score, term) => {
    if (!haystack.includes(term)) {
      return score;
    }

    const tagBoost = row.food_tags?.some((tag) => tag.toLowerCase().includes(term)) ? 3 : 0;
    const claimBoost = row.claim?.toLowerCase().includes(term) ? 2 : 0;
    return score + 1 + tagBoost + claimBoost;
  }, 0);
}

function localTerms(message: string) {
  const normalized = message
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .map((term) => term.trim())
    .filter((term) => term.length > 1);

  const synonyms: Record<string, string[]> = {
    فراخ: ["poultry", "chicken"],
    دجاج: ["poultry", "chicken"],
    الدجاج: ["poultry", "chicken"],
    بيض: ["eggs"],
    البيض: ["eggs"],
    سكر: ["sugar"],
    السكر: ["sugar"],
    عيش: ["bread", "wheat"],
    خبز: ["bread", "wheat"],
    الخبز: ["bread", "wheat"],
    قمح: ["wheat"],
    عدس: ["lentils"],
    العدس: ["lentils"],
    فول: ["fava", "beans"],
    الفول: ["fava", "beans"],
    سمن: ["ghee", "saturated"],
    السمن: ["ghee", "saturated"],
    زبدة: ["butter", "saturated"],
    الزبدة: ["butter", "saturated"],
    دهون: ["fat", "fats"],
    انسولين: ["insulin", "diabetes"],
    إنسولين: ["insulin", "diabetes"],
    الإنسولين: ["insulin", "diabetes"],
    السكرى: ["diabetes"],
    السكري: ["diabetes"],
    ضغط: ["hypertension", "blood", "pressure"],
    الضغط: ["hypertension", "blood", "pressure"],
    كيماوي: ["chemotherapy", "cancer"],
    كيميائي: ["chemotherapy", "cancer"],
    سرطان: ["cancer"],
    خبيث: ["khabaith"],
    خبائث: ["khabaith"],
    الطيبات: ["tayebat"],
    طيبات: ["tayebat"],
    الدايت: ["diet"],
    غذاء: ["diet", "nutrition"],
    الاكل: ["diet", "nutrition"],
    الأكل: ["diet", "nutrition"],
  };

  const expanded = normalized.flatMap((term) => [term, ...(synonyms[term] || [])]);
  return [...new Set(expanded)];
}
