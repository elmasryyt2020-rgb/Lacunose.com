const WINDOW_MS = 60_000;
const MAX_REQUESTS = 30;

const buckets = new Map<string, number[]>();

export function checkRateLimit(key: string, now = Date.now()) {
  const windowStart = now - WINDOW_MS;
  const recent = (buckets.get(key) || []).filter((timestamp) => timestamp > windowStart);

  if (recent.length >= MAX_REQUESTS) {
    buckets.set(key, recent);
    const resetAt = recent[0] + WINDOW_MS;
    return { allowed: false, resetAt, remaining: 0 };
  }

  recent.push(now);
  buckets.set(key, recent);
  return {
    allowed: true,
    resetAt: recent[0] + WINDOW_MS,
    remaining: MAX_REQUESTS - recent.length,
  };
}

export function resetRateLimitForTests() {
  buckets.clear();
}
