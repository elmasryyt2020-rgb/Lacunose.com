import { describe, expect, it } from "vitest";
import { getOrCreateChatSession, loadRecentChatHistory, saveChatTurn } from "./chat-store";

describe("chat store fallback behavior", () => {
  it("reuses a provided session id when Supabase chat tables are unavailable", async () => {
    const sessionId = await getOrCreateChatSession("existing-session", "en");

    expect(sessionId).toBe("existing-session");
  });

  it("creates an ephemeral session id when no stored session exists", async () => {
    const sessionId = await getOrCreateChatSession(undefined, "ar");

    expect(sessionId).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i,
    );
  });

  it("keeps an in-memory fallback history when persistence is unavailable", async () => {
    const sessionId = await getOrCreateChatSession(undefined, "en");

    await saveChatTurn({
      sessionId,
      userMessage: "hello",
      assistantAnswer: "hi",
      citations: [],
      safetyLevel: "normal",
    });

    await expect(loadRecentChatHistory(sessionId)).resolves.toEqual([
      {
        role: "user",
        content: "hello",
      },
      {
        role: "assistant",
        content: "hi",
      },
    ]);
  });
});
