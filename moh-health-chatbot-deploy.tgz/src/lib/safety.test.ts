import { describe, expect, it } from "vitest";
import { assessSafety } from "./safety";

describe("assessSafety", () => {
  it("classifies insulin stopping as urgent", () => {
    const result = assessSafety("هل يمكنني إيقاف الإنسولين والاعتماد على الدايت؟");

    expect(result.level).toBe("urgent");
    expect(result.isMedicationStopRequest).toBe(true);
  });

  it("classifies Arabic chemotherapy stopping as urgent", () => {
    const result = assessSafety("\u0647\u0644 \u0623\u0648\u0642\u0641 \u0627\u0644\u0643\u064a\u0645\u0627\u0648\u064a \u0648\u0623\u0639\u062a\u0645\u062f \u0639\u0644\u0649 \u0627\u0644\u0623\u0643\u0644\u061f");

    expect(result.level).toBe("urgent");
    expect(result.isMedicationStopRequest).toBe(true);
  });

  it("classifies nutrition questions as normal", () => {
    const result = assessSafety("هل الدجاج مصدر بروتين جيد؟");

    expect(result.level).toBe("normal");
  });

  it("classifies urgent symptoms", () => {
    const result = assessSafety("I have chest pain and shortness of breath");

    expect(result.level).toBe("urgent");
    expect(result.isUrgentSymptom).toBe(true);
  });
});
