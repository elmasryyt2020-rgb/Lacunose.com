import { describe, expect, it } from "vitest";
import { checkRateLimit, resetRateLimitForTests } from "./rate-limit";

describe("checkRateLimit", () => {
  it("allows 30 requests per minute and rejects the next one", () => {
    resetRateLimitForTests();

    for (let index = 0; index < 30; index += 1) {
      expect(checkRateLimit("visitor-a", 1_000 + index).allowed).toBe(true);
    }

    const blocked = checkRateLimit("visitor-a", 2_000);
    expect(blocked.allowed).toBe(false);
    expect(blocked.remaining).toBe(0);
  });

  it("opens the bucket again after the window moves", () => {
    resetRateLimitForTests();

    for (let index = 0; index < 30; index += 1) {
      checkRateLimit("visitor-b", 1_000 + index);
    }

    expect(checkRateLimit("visitor-b", 62_000).allowed).toBe(true);
  });
});
