import type { SafetyLevel } from "./types";

export type SafetyAssessment = {
  level: SafetyLevel;
  isMedicationStopRequest: boolean;
  isUrgentSymptom: boolean;
  reasons: string[];
};

const medicationStopPatterns = [
  /stop\s+(insulin|chemotherapy|chemo|medication|medicine|antihypertensive|anticoagulant)/i,
  /quit\s+(insulin|chemotherapy|chemo|medication|medicine)/i,
  /(إيقاف|ايقاف|وقف|توقيف|أوقف|اوقف|ابطل).{0,32}(ال)?(إنسولين|انسولين|الإنسولين|الانسولين|كيماوي|الكيمياوي|العلاج|الدواء|الأدوية|ادوية|أدوية|الضغط|السيولة)/i,
  /توق(?:ف|يف|يفي|فوا).{0,24}(ال)?(انسولين|إنسولين|كيماوي|العلاج|الدواء|الادوية|الأدوية|الضغط|السيولة)/i,
  /ابطل.{0,24}(انسولين|إنسولين|كيماوي|العلاج|الدواء|ادوية|أدوية|الضغط|السيولة)/i,
  /اوقف.{0,24}(انسولين|إنسولين|كيماوي|العلاج|الدواء|ادوية|أدوية|الضغط|السيولة)/i,
];

const urgentPatterns = [
  /chest pain|stroke|severe dehydration|fainting|shortness of breath|diabetic ketoacidosis|dka|hyperglycemic/i,
  /ألم\s+صدر|الم\s+صدر|جلطة|سكتة|جفاف\s+شديد|اغماء|إغماء|ضيق\s+تنفس|حماض\s+كيتوني|غيبوبة/i,
];

const cautionPatterns = [
  /diabetes|cancer|hypertension|blood pressure|insulin|chemotherapy|anticoagulant|medication/i,
  /سكري|سرطان|ضغط|انسولين|إنسولين|كيماوي|سيولة|دواء|أدوية|ادوية/i,
];

export function assessSafety(message: string): SafetyAssessment {
  const reasons: string[] = [];
  const isMedicationStopRequest = medicationStopPatterns.some((pattern) =>
    pattern.test(message),
  );
  const isUrgentSymptom = urgentPatterns.some((pattern) => pattern.test(message));
  const isMedicalCaution = cautionPatterns.some((pattern) => pattern.test(message));

  if (isMedicationStopRequest) {
    reasons.push("medication_stop_request");
  }

  if (isUrgentSymptom) {
    reasons.push("urgent_symptom");
  }

  if (isMedicalCaution) {
    reasons.push("medical_caution");
  }

  return {
    level: isMedicationStopRequest || isUrgentSymptom
      ? "urgent"
      : isMedicalCaution
        ? "medical_caution"
        : "normal",
    isMedicationStopRequest,
    isUrgentSymptom,
    reasons,
  };
}

export function safetyPrelude(locale: "ar" | "en", assessment: SafetyAssessment) {
  if (assessment.isMedicationStopRequest) {
    return locale === "ar"
      ? "لا توقف الإنسولين أو العلاج الكيماوي أو أدوية الضغط أو السيولة أو أي علاج موصوف بدون الرجوع للطبيب المعالج فورًا. إيقاف هذه العلاجات قد يسبب مضاعفات خطيرة وقد يهدد الحياة."
      : "Do not stop insulin, chemotherapy, blood pressure medicine, anticoagulants, or any prescribed treatment without speaking to the treating physician immediately. Stopping these treatments can cause serious, life-threatening harm.";
  }

  if (assessment.isUrgentSymptom) {
    return locale === "ar"
      ? "هذه الأعراض قد تكون طارئة. يرجى التوجه لأقرب طوارئ أو الاتصال بالإسعاف فورًا، ثم اتبع إرشادات الطبيب."
      : "These symptoms may be urgent. Please seek emergency care or call local emergency services now, then follow your clinician's advice.";
  }

  return "";
}
