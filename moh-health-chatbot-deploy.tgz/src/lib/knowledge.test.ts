import { describe, expect, it } from "vitest";
import { toCitations } from "./knowledge";
import type { KnowledgeRow } from "./types";

const baseRow: KnowledgeRow = {
  id: "row-1",
  content: "content",
  claim: "claim",
  fact_data: "fact",
  document_type: "who_guideline",
  source_authority: "WHO",
  source_url: "https://www.who.int/example",
  source_date: "2026-01-01",
  category: "nutrition",
  food_tags: [],
};

describe("toCitations", () => {
  it("keeps safe web URLs", () => {
    expect(toCitations([baseRow])[0].url).toBe("https://www.who.int/example");
  });

  it("drops non-web citation URLs", () => {
    const [citation] = toCitations([
      {
        ...baseRow,
        source_url: "javascript:alert(1)",
      },
    ]);

    expect(citation.url).toBeNull();
  });
});
