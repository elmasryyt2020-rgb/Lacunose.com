import "server-only";

import { createClient } from "@supabase/supabase-js";
import { retrieveLocalKnowledge } from "./local-knowledge";
import type { Citation, KnowledgeRow } from "./types";

const selectColumns =
  "id,content,claim,fact_data,document_type,source_authority,source_url,source_date,category,food_tags";

export function toCitations(rows: KnowledgeRow[]): Citation[] {
  const seen = new Set<string>();

  return rows
    .filter((row) => {
      if (seen.has(row.id)) {
        return false;
      }
      seen.add(row.id);
      return true;
    })
    .map((row) => ({
      id: row.id,
      authority: row.source_authority,
      url: safeCitationUrl(row.source_url),
      date: row.source_date,
      documentType: row.document_type,
    }));
}

export function buildKnowledgeContext(rows: KnowledgeRow[]) {
  if (rows.length === 0) {
    return "No verified knowledge-base rows were retrieved.";
  }

  return rows
    .map((row, index) => {
      const facts = row.fact_data || row.content;
      return [
        `[${index + 1}] ${row.source_authority} (${row.source_date || "undated"})`,
        `Claim: ${row.claim || "N/A"}`,
        `Fact: ${facts}`,
        `Category: ${row.category || "general"}`,
        `URL: ${row.source_url || "N/A"}`,
      ].join("\n");
    })
    .join("\n\n");
}

export async function retrieveKnowledge(message: string, limit = 6): Promise<KnowledgeRow[]> {
  const url = process.env.SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceRoleKey) {
    return retrieveLocalKnowledge(message, limit);
  }

  const supabase = createClient(url, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const query = normalizeSearchQuery(message);

  if (query) {
    const fullText = await supabase
      .from("medical_kb")
      .select(selectColumns)
      .textSearch("search_vector", query, {
        type: "websearch",
        config: "english",
      })
      .limit(limit);

    if (!fullText.error && fullText.data && fullText.data.length > 0) {
      return fullText.data as KnowledgeRow[];
    }

    if (fullText.error) {
      logSupabaseError("full_text", fullText.error);
    }
  }

  const terms = keywordTerms(message).slice(0, 5);
  if (terms.length === 0) {
    return retrieveLocalKnowledge(message, limit);
  }

  const filters = terms.flatMap((term) => {
    const escaped = escapeIlike(term);
    return [
      `content.ilike.%${escaped}%`,
      `claim.ilike.%${escaped}%`,
      `fact_data.ilike.%${escaped}%`,
    ];
  });

  const fallback = await supabase
    .from("medical_kb")
    .select(selectColumns)
    .or(filters.join(","))
    .limit(limit);

  if (fallback.error || !fallback.data) {
    if (fallback.error) {
      logSupabaseError("fallback", fallback.error);
    }
    return retrieveLocalKnowledge(message, limit);
  }

  if (fallback.data.length > 0) {
    return fallback.data as KnowledgeRow[];
  }

  return retrieveLocalKnowledge(message, limit);
}

function logSupabaseError(stage: string, error: { message?: string; code?: string }) {
  console.warn("[medical_kb] Supabase retrieval failed", {
    stage,
    code: error.code,
    message: error.message,
  });
}

function normalizeSearchQuery(message: string) {
  return keywordTerms(message)
    .slice(0, 8)
    .join(" ");
}

function keywordTerms(message: string) {
  const normalized = message
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .map((term) => term.trim())
    .filter(Boolean);

  const expanded = normalized.flatMap((term) => [term, ...searchSynonyms(term)]);
  return [...new Set(expanded)].filter((term) => term.length > 1);
}

function searchSynonyms(term: string) {
  const synonyms: Record<string, string[]> = {
    فراخ: ["chicken", "poultry"],
    دجاج: ["chicken", "poultry"],
    الدجاج: ["chicken", "poultry"],
    بيض: ["eggs"],
    البيض: ["eggs"],
    عيش: ["bread", "wheat"],
    خبز: ["bread", "wheat"],
    الخبز: ["bread", "wheat"],
    قمح: ["wheat"],
    العدس: ["lentils"],
    عدس: ["lentils"],
    فول: ["fava", "beans"],
    الفول: ["fava", "beans"],
    سمن: ["ghee"],
    السمن: ["ghee"],
    زبدة: ["butter"],
    الزبدة: ["butter"],
    سكر: ["sugar"],
    السكر: ["sugar"],
    انسولين: ["insulin", "diabetes"],
    إنسولين: ["insulin", "diabetes"],
    الإنسولين: ["insulin", "diabetes"],
    السكري: ["diabetes"],
    السكرى: ["diabetes"],
    ضغط: ["hypertension", "blood", "pressure"],
    الضغط: ["hypertension", "blood", "pressure"],
    كيماوي: ["chemotherapy", "cancer"],
    كيميائي: ["chemotherapy", "cancer"],
    سرطان: ["cancer"],
    خبائث: ["khabaith"],
    خبيث: ["khabaith"],
    الطيبات: ["tayebat"],
    طيبات: ["tayebat"],
  };

  return synonyms[term] || [];
}

function escapeIlike(value: string) {
  return value.replace(/[%_]/g, (match) => `\\${match}`);
}

function safeCitationUrl(value?: string | null) {
  if (!value) {
    return null;
  }

  try {
    const parsed = new URL(value);
    if (!["http:", "https:"].includes(parsed.protocol)) {
      return null;
    }

    return parsed.toString();
  } catch {
    return null;
  }
}
