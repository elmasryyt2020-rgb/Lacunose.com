import { describe, expect, it } from "vitest";
import { detectLocale, directionForLocale } from "./locale";

describe("locale helpers", () => {
  it("defaults Arabic messages to Arabic", () => {
    expect(detectLocale("ما حقيقة نظام الطيبات؟")).toBe("ar");
    expect(directionForLocale("ar")).toBe("rtl");
  });

  it("uses English for English messages", () => {
    expect(detectLocale("Is butter healthy?")).toBe("en");
    expect(directionForLocale("en")).toBe("ltr");
  });
});
