import { describe, expect, it } from "vitest";
import { retrieveLocalKnowledge } from "./local-knowledge";

describe("retrieveLocalKnowledge", () => {
  it("retrieves poultry and food safety rows for Arabic chicken questions", () => {
    const rows = retrieveLocalKnowledge("هل الدجاج مضر ويسبب الالتهاب؟");

    expect(rows.length).toBeGreaterThan(0);
    expect(rows.some((row) => row.food_tags?.includes("poultry"))).toBe(true);
    expect(rows.some((row) => row.source_authority.includes("WHO"))).toBe(true);
  });

  it("retrieves insulin safety rows for diabetes medication questions", () => {
    const rows = retrieveLocalKnowledge("هل يمكن إيقاف الإنسولين والاعتماد على الأكل؟");

    expect(rows.length).toBeGreaterThan(0);
    expect(rows.some((row) => row.food_tags?.includes("insulin"))).toBe(true);
  });

  it("falls back to general trusted rows for unclear questions", () => {
    const rows = retrieveLocalKnowledge("سؤال عام جدا");

    expect(rows.length).toBeGreaterThan(0);
    expect(rows.some((row) => row.id === "local-healthy-diet-who-2026")).toBe(true);
  });
});
