import type { Locale } from "./types";

const arabicPattern = /[\u0600-\u06ff]/;

export function detectLocale(message: string, requested?: string): Locale {
  if (requested === "ar" || requested === "en") {
    return requested;
  }

  return arabicPattern.test(message) ? "ar" : "en";
}

export function directionForLocale(locale: Locale): "rtl" | "ltr" {
  return locale === "ar" ? "rtl" : "ltr";
}
