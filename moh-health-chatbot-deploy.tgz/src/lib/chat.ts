import {
  getOrCreateChatSession,
  loadRecentChatHistory,
  saveChatTurn,
} from "./chat-store";
import { generateWithGemini } from "./gemini";
import { buildKnowledgeContext, retrieveKnowledge, toCitations } from "./knowledge";
import { detectLocale } from "./locale";
import { assessSafety, safetyPrelude } from "./safety";
import type {
  ChatHistoryMessage,
  ChatRequest,
  ChatResponse,
  Citation,
  KnowledgeRow,
  Locale,
  SafetyLevel,
} from "./types";

type ChatDeps = {
  retrieve?: (message: string) => Promise<KnowledgeRow[]>;
  generate?: (prompt: string, systemInstruction: string) => Promise<string>;
  createSession?: (sessionId: string | undefined, locale: Locale) => Promise<string>;
  loadHistory?: (sessionId: string) => Promise<ChatHistoryMessage[]>;
  saveTurn?: (params: {
    sessionId: string;
    userMessage: string;
    assistantAnswer: string;
    citations: Citation[];
    safetyLevel: SafetyLevel;
  }) => Promise<void>;
};

export async function handleChat(
  request: ChatRequest,
  deps: ChatDeps = {},
): Promise<ChatResponse> {
  const message = request.message?.trim();
  if (!message) {
    return {
      answer: "من فضلك اكتب سؤالك الصحي بوضوح.",
      citations: [],
      safetyLevel: "normal",
      sessionId: request.sessionId || "",
    };
  }

  const locale = detectLocale(message, request.locale);
  const sessionId = await (deps.createSession || getOrCreateChatSession)(
    request.sessionId,
    locale,
  );
  const history = request.sessionId
    ? await (deps.loadHistory || loadRecentChatHistory)(sessionId)
    : [];
  const assessment = assessSafety(message);
  const rows = await (deps.retrieve || retrieveKnowledge)(
    buildRetrievalQuery(message, history),
  );
  const citations = toCitations(rows);
  const prelude = safetyPrelude(locale, assessment);

  if (assessment.isMedicationStopRequest || assessment.isUrgentSymptom) {
    const answer = withDisclaimer(
      locale,
      [prelude, evidenceSummary(locale, rows)].filter(Boolean).join("\n\n"),
    );
    await (deps.saveTurn || saveChatTurn)({
      sessionId,
      userMessage: message,
      assistantAnswer: answer,
      citations,
      safetyLevel: assessment.level,
    });

    return {
      answer,
      citations,
      safetyLevel: assessment.level,
      sessionId,
    };
  }

  const prompt = buildUserPrompt(message, locale, rows, history);
  const systemInstruction = buildSystemInstruction(locale);
  const generated = await (deps.generate || generateWithGemini)(prompt, systemInstruction);
  const finalAnswer = withDisclaimer(locale, generated || evidenceSummary(locale, rows));

  await (deps.saveTurn || saveChatTurn)({
    sessionId,
    userMessage: message,
    assistantAnswer: finalAnswer,
    citations,
    safetyLevel: assessment.level,
  });

  return {
    answer: finalAnswer,
    citations,
    safetyLevel: assessment.level,
    sessionId,
  };
}

export function buildSystemInstruction(locale: Locale) {
  const languageRule =
    locale === "ar"
      ? "Answer in Arabic by default, using clear Egyptian public-health support language."
      : "Answer in English because the visitor used English.";

  return [
    "You are an Egypt Ministry of Health visitor-support chatbot.",
    languageRule,
    "Use only the verified knowledge-base context provided by the server.",
    "Use the recent conversation context only to resolve follow-up references such as 'that doctor', 'that video', or 'this diet'.",
    "Do not diagnose, prescribe, or personalize treatment.",
    "Never tell users to stop prescribed medication. Escalate urgent symptoms to emergency care.",
    "Be concise, calm, and cite source authorities naturally.",
    "Use simple public language. Keep most answers under 90 words and prefer 2 short paragraphs or 3 bullets.",
    "Give a practical starting point: what is trusted, what to avoid, and when to ask a clinician.",
    "Do not write a separate disclaimer; the server appends one.",
    "If evidence is limited for the exact wording, answer from the closest verified public-health principles instead of saying the database is empty.",
  ].join(" ");
}

function buildUserPrompt(
  message: string,
  locale: Locale,
  rows: KnowledgeRow[],
  history: ChatHistoryMessage[],
) {
  return [
    `Visitor locale: ${locale}`,
    "Recent conversation context:",
    formatHistory(history),
    "",
    `Visitor question: ${message}`,
    "",
    "Verified knowledge-base context:",
    buildKnowledgeContext(rows),
    "",
    "Write a practical answer for a public website visitor. Include a short note that this is public health information, not a diagnosis.",
  ].join("\n");
}

function buildRetrievalQuery(message: string, history: ChatHistoryMessage[]) {
  const context = history
    .slice(-4)
    .map((turn) => turn.content)
    .join(" ");

  return [context, message].filter(Boolean).join(" ");
}

function formatHistory(history: ChatHistoryMessage[]) {
  if (history.length === 0) {
    return "No previous turns in this session.";
  }

  return history
    .slice(-8)
    .map((message) => {
      const speaker = message.role === "user" ? "Visitor" : "Assistant";
      return `${speaker}: ${truncateForPrompt(message.content)}`;
    })
    .join("\n");
}

function truncateForPrompt(value: string) {
  const normalized = value.replace(/\s+/g, " ").trim();
  return normalized.length > 700 ? `${normalized.slice(0, 700)}...` : normalized;
}

function evidenceSummary(locale: Locale, rows: KnowledgeRow[]) {
  if (rows.length === 0) {
    return locale === "ar"
      ? "كنقطة بداية موثوقة: اتبع نظامًا غذائيًا متوازنًا، ولا توقف أي دواء موصوف بدون الطبيب، واطلب رعاية عاجلة عند ظهور أعراض خطيرة مثل ألم الصدر أو أعراض الجلطة أو الجفاف الشديد. للمعلومات الشخصية أو العلاج، استشر الطبيب المختص."
      : "As a trusted starting point: follow a balanced diet, do not stop any prescribed medicine without your clinician, and seek urgent care for serious symptoms such as chest pain, stroke signs or severe dehydration. For personal treatment, consult a qualified clinician.";
  }

  const topFacts = rows
    .slice(0, 3)
    .map((row) => row.fact_data || row.content)
    .filter(Boolean);

  if (locale === "ar") {
    return `وفقًا للمصادر الموثقة المتاحة: ${topFacts.join(" ")}`;
  }

  return `According to the available verified sources: ${topFacts.join(" ")}`;
}

function withDisclaimer(locale: Locale, answer: string) {
  const disclaimer =
    locale === "ar"
      ? "هذه معلومات صحية عامة وليست تشخيصًا أو بديلًا عن استشارة الطبيب."
      : "This is general public health information, not a diagnosis or a substitute for medical advice.";

  return `${answer.trim()}\n\n${disclaimer}`;
}
