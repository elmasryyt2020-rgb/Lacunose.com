import "server-only";

import { randomUUID } from "crypto";
import { createClient } from "@supabase/supabase-js";
import type { ChatHistoryMessage, Citation, Locale, SafetyLevel } from "./types";

const HISTORY_LIMIT = 8;
const memorySessions = new Set<string>();
const memoryMessages = new Map<string, ChatHistoryMessage[]>();

type ChatMessageRow = {
  role: "user" | "assistant";
  content: string;
};

function supabaseAdmin() {
  const url = process.env.SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceRoleKey) {
    return null;
  }

  return createClient(url, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export async function getOrCreateChatSession(sessionId: string | undefined, locale: Locale) {
  const supabase = supabaseAdmin();
  if (!supabase) {
    return getOrCreateMemorySession(sessionId);
  }

  if (sessionId) {
    const existing = await supabase
      .from("chat_sessions")
      .select("id")
      .eq("id", sessionId)
      .maybeSingle();

    if (!existing.error && existing.data?.id) {
      return existing.data.id as string;
    }

    if (existing.error?.code === "PGRST205") {
      return getOrCreateMemorySession(sessionId);
    }
  }

  const created = await supabase
    .from("chat_sessions")
    .insert({ locale })
    .select("id")
    .single();

  if (created.error || !created.data?.id) {
    console.warn("[chat_sessions] Unable to create chat session", {
      message: created.error?.message,
      code: created.error?.code,
    });
    return getOrCreateMemorySession();
  }

  return created.data.id as string;
}

export async function loadRecentChatHistory(sessionId: string): Promise<ChatHistoryMessage[]> {
  const supabase = supabaseAdmin();
  if (!supabase) {
    return loadMemoryHistory(sessionId);
  }

  const result = await supabase
    .from("chat_messages")
    .select("role,content")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: false })
    .limit(HISTORY_LIMIT);

  if (result.error || !result.data) {
    console.warn("[chat_messages] Unable to load chat history", {
      message: result.error?.message,
      code: result.error?.code,
    });
    if (result.error?.code === "PGRST205") {
      return loadMemoryHistory(sessionId);
    }
    return [];
  }

  return (result.data as ChatMessageRow[])
    .reverse()
    .filter((message) => message.role === "user" || message.role === "assistant")
    .map((message) => ({
      role: message.role,
      content: message.content,
    }));
}

export async function saveChatTurn(params: {
  sessionId: string;
  userMessage: string;
  assistantAnswer: string;
  citations: Citation[];
  safetyLevel: SafetyLevel;
}) {
  const supabase = supabaseAdmin();
  if (!supabase) {
    saveMemoryTurn(params.sessionId, params.userMessage, params.assistantAnswer);
    return;
  }

  const messages = [
    {
      session_id: params.sessionId,
      role: "user",
      content: params.userMessage,
      citations: null,
      safety_level: null,
    },
    {
      session_id: params.sessionId,
      role: "assistant",
      content: params.assistantAnswer,
      citations: params.citations,
      safety_level: params.safetyLevel,
    },
  ];

  const result = await supabase.from("chat_messages").insert(messages);

  if (result.error) {
    console.warn("[chat_messages] Unable to save chat turn", {
      message: result.error.message,
      code: result.error.code,
    });
    if (result.error.code === "PGRST205") {
      saveMemoryTurn(params.sessionId, params.userMessage, params.assistantAnswer);
    }
    return;
  }

  await supabase
    .from("chat_sessions")
    .update({ updated_at: new Date().toISOString() })
    .eq("id", params.sessionId);
}

function getOrCreateMemorySession(sessionId?: string) {
  const id = sessionId || randomUUID();
  memorySessions.add(id);
  if (!memoryMessages.has(id)) {
    memoryMessages.set(id, []);
  }
  return id;
}

function loadMemoryHistory(sessionId: string) {
  return (memoryMessages.get(sessionId) || []).slice(-HISTORY_LIMIT);
}

function saveMemoryTurn(sessionId: string, userMessage: string, assistantAnswer: string) {
  getOrCreateMemorySession(sessionId);
  const current = memoryMessages.get(sessionId) || [];
  current.push(
    { role: "user", content: userMessage },
    { role: "assistant", content: assistantAnswer },
  );
  memoryMessages.set(sessionId, current.slice(-HISTORY_LIMIT));
}
