export type Locale = "ar" | "en";

export type SafetyLevel = "normal" | "medical_caution" | "urgent";

export type Citation = {
  id: string;
  authority: string;
  url: string | null;
  date: string | null;
  documentType: string;
};

export type KnowledgeRow = {
  id: string;
  content: string;
  claim: string | null;
  fact_data: string | null;
  document_type: string;
  source_authority: string;
  source_url: string | null;
  source_date: string | null;
  category: string | null;
  food_tags: string[] | null;
};

export type ChatHistoryMessage = {
  role: "user" | "assistant";
  content: string;
};

export type ChatRequest = {
  message: string;
  sessionId?: string;
  locale?: Locale;
};

export type ChatResponse = {
  answer: string;
  citations: Citation[];
  safetyLevel: SafetyLevel;
  sessionId: string;
};
