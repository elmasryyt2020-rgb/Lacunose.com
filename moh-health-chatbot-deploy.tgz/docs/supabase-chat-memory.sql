create table if not exists public.chat_sessions (
  id uuid primary key default gen_random_uuid(),
  locale text not null default 'ar' check (locale in ('ar', 'en')),
  created_at timestamp with time zone not null default now(),
  updated_at timestamp with time zone not null default now()
);

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.chat_sessions(id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  citations jsonb,
  safety_level text check (safety_level in ('normal', 'medical_caution', 'urgent')),
  created_at timestamp with time zone not null default now()
);

create index if not exists chat_messages_session_created_idx
  on public.chat_messages(session_id, created_at desc);

alter table public.chat_sessions enable row level security;
alter table public.chat_messages enable row level security;

-- The application writes through SUPABASE_SERVICE_ROLE_KEY on the server only.
-- Do not create public anon policies for these tables.
