# Knowledge Base Coverage

This preview uses Supabase `medical_kb` as the production source of truth and now includes a local official-source starter corpus in `src/lib/local-knowledge.ts`. The local corpus is a fallback for development and for moments when Supabase credentials are missing or invalid.

## What We Have And Why

| Area | Main sources | Why it is included |
| --- | --- | --- |
| Healthy diet basics | WHO healthy diet fact sheet | Gives visitors a trusted baseline: whole grains, vegetables, fruits, legumes, nuts, less salt, free sugar, saturated fat and trans fat. |
| Fats, ghee, butter and oils | WHO saturated/trans fat guideline | Directly addresses claims that ghee or butter are special health foods or clean arteries. |
| Carbohydrates, bread and grains | WHO carbohydrate guidance, FAO Egypt Nutrition Country Profile | Counters claims that all carbs, bread or wheat are poison while still warning about excess free sugars. |
| Salt and blood pressure | WHO sodium reduction guidance | Supports clear public advice around hypertension and excess salt. |
| Diabetes and insulin | WHO diabetes fact sheet | Makes the bot safe around insulin and diet-only diabetes claims. |
| Hypertension medicine | WHO hypertension fact sheet | Explains that lifestyle helps but many patients still need medicine. |
| Cardiovascular disease | WHO CVD fact sheet | Covers heart attack/stroke prevention and why medicines may be necessary for high-risk people. |
| Physical activity | WHO physical activity fact sheet | Prevents over-focusing on diet alone and gives a simple health baseline. |
| Food safety, poultry and eggs | WHO food safety guidance | Separates real contamination/undercooking risks from false “toxic food” claims. |
| Cancer treatment and chemotherapy | WHO cancer treatment material | Ensures the bot never frames diet as a replacement for oncology care. |
| Egyptian staple foods | FAO/INFOODS Egypt tables and FAO Egypt profile | Grounds answers in Egyptian food patterns: bread, cereals, fava beans, lentils, dairy, fruits and vegetables. |
| Tayebat/Khabaith classification | FAO/INFOODS food composition approach | Explains that food tables classify nutrients, not moral/toxic labels. |
| Egypt Ministry of Health context | Egypt MoHP campaign reporting and regulator reporting | Covers the public controversy, official health messaging, and why users should trust verified health authorities. |
| Core medication safety | WHO plus Egyptian medical authority context | Provides a universal guardrail for insulin, chemotherapy, blood pressure medicines, anticoagulants and other prescribed medicines. |

## Current Retrieval Status

Supabase retrieval is working with the current `.env.local` credentials. The local corpus remains as a development fallback if credentials are missing or Supabase retrieval fails.

For a source-by-source trust review, see `docs/source-audit.md`.

## Next Best Additions

- Official Arabic MoHP pages or PDFs, if available, for direct Ministry wording.
- Egyptian Medical Syndicate statements as primary-source documents.
- More Egypt NNI food composition rows for common foods: rice, pasta, fish, dairy, oils, vegetables and fruits.
- Emergency escalation content in Arabic for DKA, stroke symptoms, chest pain and severe dehydration.
- A small editorial review workflow so every row has source authority, source date, category, claim, rebuttal and tags.
