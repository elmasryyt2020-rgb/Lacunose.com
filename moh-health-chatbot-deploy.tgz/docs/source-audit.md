# Source Audit

This audit covers the Supabase `medical_kb` source URLs and the local fallback knowledge base in `src/lib/local-knowledge.ts`.

## Trust Tiers

| Tier | Meaning | Current sources |
| --- | --- | --- |
| Primary authority | Official public-health, nutrition, or food-data source. Best for production answers. | WHO, FAO, FAO/INFOODS, Egypt NNI when available through FAO. |
| Professional clinical authority | Reputable medical guideline or specialty body. Good, but should use exact guideline pages. | ADA/Diabetes Care, Endocrine Society, ASCO, AHA. |
| Secondary report | News article reporting official Egyptian actions or campaigns. Useful for preview context only. | EgyptToday reports on MoHP campaign and SCMR/MoHP/Syndicate action. |

## Unique Sources

| Source | Trust | Why we use it | Information it provides | Production note |
| --- | --- | --- | --- | --- |
| WHO healthy diet fact sheet | Primary authority | Gives the general nutrition baseline for all fallback answers. | Balanced diet, fruits/vegetables, whole grains, legumes, nuts, salt, free sugar, saturated fat, trans fat. | Keep. |
| WHO fats and carbohydrates guideline/news update | Primary authority | Directly rebuts ghee/butter/artery and all-carbs-are-poison claims. | Saturated fat and trans fat limits, unsaturated fat replacement, carbohydrate quality. | Keep. |
| WHO saturated and trans-fatty acids publication | Primary authority | More formal source for fat-quality guidance. | Saturated/trans-fat definitions, replacement recommendations, health-risk framing. | Keep. |
| WHO salt reduction fact sheet | Primary authority | Supports hypertension and sodium public guidance. | Less than 5g salt/day for adults, high sodium and blood pressure/CVD risk. | Keep. |
| WHO diabetes fact sheet | Primary authority | Core safety source for insulin and diabetes claims. | Diabetes definition, insulin role, complications and medical management. | Keep. |
| WHO hypertension fact sheet | Primary authority | Prevents unsafe advice to stop blood-pressure medicine. | Lifestyle risk factors plus the fact that many patients need medication. | Keep. |
| WHO cardiovascular diseases fact sheet | Primary authority | Covers heart attack/stroke risk and prevention. | Diet, activity, tobacco/alcohol risks; medical treatment for hypertension, diabetes and lipids when needed. | Keep. |
| WHO physical activity fact sheet | Primary authority | Avoids diet-only framing. | Activity targets and role in NCD prevention/management. | Keep. |
| WHO food safety fact sheet and WHO Europe food safety advice | Primary authority | Separates foodborne-risk advice from false "toxic food" claims. | Clean/separate/cook/chill principles; animal foods require safe handling, not blanket avoidance. | Keep. |
| WHO obesity and overweight fact sheet | Primary authority | Counters "eat unlimited to fullness" claims. | Obesity as chronic disease, healthy diet/activity, clinical management when needed. | Keep. |
| WHO cancer treatment material | Primary authority | Safety anchor for chemotherapy-abandonment questions. | Cancer care may include surgery, radiotherapy, chemotherapy and other treatments. | Keep, but add newer oncology sources too. |
| FAO Nutrition Country Profile: Egypt (2003) | Primary institutional source | Grounds answers in Egypt-specific diet patterns. | Bread/cereals, pulses, fruits/vegetables, dairy, national nutrition context. | Keep. |
| FAO/INFOODS Egypt food composition tables page | Primary institutional source | Grounds food answers in nutrient data rather than moral labels. | Egypt NNI food tables; nutrient-based classification of foods. | Keep. |
| Diabetes Care/ADA issue page | Professional clinical authority | Supports diabetes and calorie/portion guidance. | Diabetes standards and clinical management context. | Replace broad issue URL with exact Standards of Care page/PDF. |
| AHA references in rows | Professional clinical authority | Supports cardiovascular fat-risk framing. | Saturated fat and cardiovascular-risk context. | Add exact AHA URL if retained in `source_authority`. |
| ASCO references in rows | Professional clinical authority | Supports oncology medication safety. | Cancer-treatment authority context. | Add exact ASCO guideline/source URL if retained in `source_authority`. |
| EgyptToday report on "Inta El Hal" MoHP campaign | Secondary report | Provides Egypt-specific public-health campaign context when official pages are unavailable. | Campaign against overeating and excess sugar, reported as Ministry of Health messaging. | Replace with official MoHP link if available. |
| EgyptToday report on SCMR/MoHP/Syndicate action against Diaa Elawady content | Secondary report | Covers the controversy driving this chatbot preview. | Media-regulator action, MoHP/Syndicate concern about harmful unverified medical advice. | Replace with official SCMR, MoHP, or Syndicate statement for production. |

## Supabase Row Notes

Most Supabase rows are rebuttal-style records: a `claim`, an evidence-backed `fact_data`, a `source_authority`, and a `source_url`. The data currently focuses on poultry, bread/wheat, eggs, lentils, fava beans, dairy, fish, ghee/butter, sugar/carbs, insulin, chemotherapy, hypertension medicine, and the "Tayebat/Khabaith" controversy.

The main quality issue is not the topics; it is source precision. Several rows name strong authorities such as AHA, ASCO, WHO, ADA, or Egyptian medical authorities, but the `source_url` points to a broader page or a secondary news report. For the preview this is acceptable with clear caveats. For Ministry production, each row should point to the exact official statement, guideline, or PDF that supports the row.
