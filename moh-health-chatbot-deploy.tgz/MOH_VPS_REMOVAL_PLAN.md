# MOH VPS Removal Plan

This documents how to remove the MOH health chatbot deployment from the Lacunose VPS later.

## Deployment Pieces

- Domain: `moh.lacunose.com` (`MOH.lacunose.com` is equivalent because DNS is case-insensitive)
- DNS record: `A` record named `moh` pointing to `187.127.75.87`
- App directory: `/home/deploy/moh-health-chatbot`
- Docker image: `moh-health-chatbot:latest`
- Docker container: `moh-health-chatbot`
- Docker Compose file changed: `/home/deploy/lacunose-backend/docker-compose.yml`
- Caddy file changed: `/root/supabase/docker/Caddyfile`

## Removal Steps

1. Remove the Caddy route from `/root/supabase/docker/Caddyfile`:

   ```caddy
   moh.lacunose.com {
       reverse_proxy moh-health-chatbot:3000
   }
   ```

2. Restart Caddy so the route is no longer served:

   ```bash
   docker restart supabase-caddy
   ```

3. Remove the `moh-health-chatbot` service block from `/home/deploy/lacunose-backend/docker-compose.yml`.

4. Stop and remove the app container:

   ```bash
   cd /home/deploy/lacunose-backend
   docker compose stop moh-health-chatbot
   docker compose rm -f moh-health-chatbot
   ```

5. Remove the app image if it is no longer needed:

   ```bash
   docker image rm moh-health-chatbot:latest
   ```

6. Remove the deployed app directory:

   ```bash
   rm -rf /home/deploy/moh-health-chatbot
   ```

7. Delete the DNS `A` record for `moh` from the domain DNS provider.

8. Verify removal:

   ```bash
   docker ps --format "table {{.Names}}\t{{.Status}}" | grep moh || true
   curl -I https://moh.lacunose.com
   ```
