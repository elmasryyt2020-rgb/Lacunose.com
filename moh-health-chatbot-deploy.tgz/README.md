# MOH Egypt Health Chatbot Preview

Arabic-first Next.js preview and API-backed chatbot for Egypt Ministry of Health visitor support around the "Nizam Al-Tayyibat" controversy.

## Features

- Next.js App Router preview page at `GET /`
- API endpoint at `POST /api/chat`
- Future embed script at `GET /embed/moh-chatbot.js`
- Supabase retrieval from the `medical_kb` table
- Gemini response generation with `gemini-3.1-flash-lite` by default
- Medical safety guardrails for medication stopping and urgent symptoms
- Source citations mapped from `source_authority`, `source_url`, and `source_date`

## Environment

Copy `.env.example` to `.env.local` and fill:

```env
GEMINI_API_KEY=
GEMINI_MODEL=gemini-3.1-flash-lite
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
```

The app runs without credentials for UI development, but `/api/chat` will only return grounded knowledge-base answers after Supabase and Gemini credentials are configured.

## API Contract

`POST /api/chat`

```json
{
  "message": "هل يمكن إيقاف الإنسولين؟",
  "sessionId": "optional-session-id",
  "locale": "ar"
}
```

Response:

```json
{
  "answer": "...",
  "citations": [],
  "safetyLevel": "urgent",
  "sessionId": "..."
}
```

## Commands

```bash
npm run dev
npm run lint
npm run typecheck
npm run test
npm run build
```
